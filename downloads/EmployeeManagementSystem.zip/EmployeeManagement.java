import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    String name;
    int id;

    Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }
}

public class EmployeeManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();

        while (true) {
            System.out.println("\n1. Add Employee\n2. View Employees\n3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter Employee ID: ");
                int id = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter Employee Name: ");
                String name = scanner.nextLine();
                employees.add(new Employee(id, name));
                System.out.println("Employee added successfully!");
            } else if (choice == 2) {
                System.out.println("Employee List:");
                for (Employee emp : employees) {
                    System.out.println(emp.id + ": " + emp.name);
                }
            } else {
                System.out.println("Exiting system.");
                break;
            }
        }
        scanner.close();
    }
}