let people = parseInt(prompt("Enter number of people:"));
let totalAmount = parseFloat(prompt("Enter total expense amount:"));
let share = totalAmount / people;

console.log(`Each person should pay: $${share.toFixed(2)}`);