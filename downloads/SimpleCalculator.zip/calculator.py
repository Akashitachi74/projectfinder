def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b if b != 0 else "Cannot divide by zero"

print("Simple Calculator")
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
operation = input("Choose operation (+, -, *, /): ")

if operation == '+':
    print("Result:", add(a, b))
elif operation == '-':
    print("Result:", subtract(a, b))
elif operation == '*':
    print("Result:", multiply(a, b))
elif operation == '/':
    print("Result:", divide(a, b))
else:
    print("Invalid operation")