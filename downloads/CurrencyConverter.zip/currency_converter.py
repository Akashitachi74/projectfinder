def convert(amount, rate):
    return amount * rate

amount = float(input("Enter amount in USD: "))
rate = 82.5  # Example conversion rate to INR
print(f"Equivalent in INR: {convert(amount, rate)}")