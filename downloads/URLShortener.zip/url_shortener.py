import pyshorteners

def shorten_url(long_url):
    s = pyshorteners.Shortener()
    return s.tinyurl.short(long_url)

url = input("Enter the URL to shorten: ")
short_url = shorten_url(url)
print("Shortened URL:", short_url)