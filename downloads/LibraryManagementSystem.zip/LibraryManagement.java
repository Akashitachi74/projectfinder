import java.util.ArrayList;
import java.util.Scanner;

class Book {
    String title;
    String author;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
}

public class LibraryManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Book> books = new ArrayList<>();

        while (true) {
            System.out.println("\n1. Add Book\n2. View Books\n3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter Book Title: ");
                String title = scanner.nextLine();
                System.out.print("Enter Author: ");
                String author = scanner.nextLine();
                books.add(new Book(title, author));
                System.out.println("Book added!");
            } else if (choice == 2) {
                for (Book book : books) {
                    System.out.println("Title: " + book.title + ", Author: " + book.author);
                }
            } else {
                System.out.println("Exiting...");
                break;
            }
        }
        scanner.close();
    }
}