expenses = []

def add_expense(name, amount):
    expenses.append((name, amount))
    print(f"Added {name}: ${amount}")

def view_expenses():
    total = sum(amount for _, amount in expenses)
    for name, amount in expenses:
        print(f"{name}: ${amount}")
    print(f"Total Expenses: ${total}")

while True:
    print("\n1. Add Expense\n2. View Expenses\n3. Exit")
    choice = input("Choose an option: ")
    
    if choice == '1':
        name = input("Enter expense name: ")
        amount = float(input("Enter amount: "))
        add_expense(name, amount)
    elif choice == '2':
        view_expenses()
    elif choice == '3':
        print("Exiting...")
        break
    else:
        print("Invalid choice, try again.")