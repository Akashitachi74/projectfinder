import java.util.ArrayList;
import java.util.Scanner;

class Room {
    int roomNumber;
    boolean isBooked;

    Room(int roomNumber) {
        this.roomNumber = roomNumber;
        this.isBooked = false;
    }
}

public class HotelManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Room> rooms = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            rooms.add(new Room(i));
        }

        while (true) {
            System.out.println("\n1. Book Room\n2. View Rooms\n3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("Enter room number to book: ");
                int roomNum = scanner.nextInt();
                if (roomNum > 0 && roomNum <= 5 && !rooms.get(roomNum - 1).isBooked) {
                    rooms.get(roomNum - 1).isBooked = true;
                    System.out.println("Room " + roomNum + " booked successfully.");
                } else {
                    System.out.println("Invalid room number or already booked.");
                }
            } else if (choice == 2) {
                for (Room room : rooms) {
                    System.out.println("Room " + room.roomNumber + " - " + (room.isBooked ? "Booked" : "Available"));
                }
            } else {
                System.out.println("Exiting system.");
                break;
            }
        }
        scanner.close();
    }
}