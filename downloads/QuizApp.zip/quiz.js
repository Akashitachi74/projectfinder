const questions = [
    { question: 'What is 2 + 2?', answer: '4' },
    { question: 'What is the capital of France?', answer: 'Paris' }
];

let score = 0;
questions.forEach(q => {
    let userAnswer = prompt(q.question);
    if (userAnswer.toLowerCase() === q.answer.toLowerCase()) {
        score++;
    }
});
console.log(`You scored ${score}/${questions.length}`);