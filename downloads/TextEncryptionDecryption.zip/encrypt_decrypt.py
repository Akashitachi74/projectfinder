from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher = Fernet(key)

text = input("Enter text to encrypt: ")
encrypted_text = cipher.encrypt(text.encode())
print("Encrypted:", encrypted_text)

decrypted_text = cipher.decrypt(encrypted_text).decode()
print("Decrypted:", decrypted_text)