async function getWeather(city) {
    let response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=YOUR_API_KEY`);
    let data = await response.json();
    console.log(`Weather in ${city}: ${data.weather[0].description}, Temp: ${data.main.temp}K`);
}

let city = prompt("Enter city name:");
getWeather(city);