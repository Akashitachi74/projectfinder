import java.util.HashMap;
import java.util.Scanner;

public class ContactManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashMap<String, String> contacts = new HashMap<>();

        while (true) {
            System.out.println("\n1. Add Contact\n2. View Contacts\n3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phone = scanner.nextLine();
                contacts.put(name, phone);
                System.out.println("Contact added successfully!");
            } else if (choice == 2) {
                System.out.println("Contacts List:");
                for (String name : contacts.keySet()) {
                    System.out.println(name + ": " + contacts.get(name));
                }
            } else {
                System.out.println("Exiting system.");
                break;
            }
        }
        scanner.close();
    }
}