let notes = [];
function addNote(note) {
    notes.push(note);
    console.log("Note Added:", note);
}
function viewNotes() {
    console.log("Your Notes:", notes);
}
addNote(prompt("Enter a note:"));
viewNotes();