import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 12345))
server.listen(5)
print("Server started...")

client_socket, addr = server.accept()
print(f"Connection from {addr} established.")

while True:
    message = client_socket.recv(1024).decode()
    if message.lower() == "bye":
        print("Client disconnected.")
        break
    print(f"Client: {message}")
    response = input("You: ")
    client_socket.send(response.encode())

server.close()