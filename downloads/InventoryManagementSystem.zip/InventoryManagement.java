import java.util.ArrayList;
import java.util.Scanner;

class Product {
    String name;
    int quantity;

    Product(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}

public class InventoryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Product> inventory = new ArrayList<>();

        while (true) {
            System.out.println("\n1. Add Product\n2. View Inventory\n3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter Product Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Quantity: ");
                int quantity = scanner.nextInt();
                inventory.add(new Product(name, quantity));
                System.out.println("Product added successfully!");
            } else if (choice == 2) {
                System.out.println("Inventory List:");
                for (Product p : inventory) {
                    System.out.println(p.name + " - Quantity: " + p.quantity);
                }
            } else {
                System.out.println("Exiting system.");
                break;
            }
        }
        scanner.close();
    }
}